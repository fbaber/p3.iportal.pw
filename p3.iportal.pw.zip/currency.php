<!-- javascript functions file -->
<script type="text/javascript" src="js/javascript.js"> </script>
<!--<form method='POST' class="userform"> 
	<br>
	<h3>Please select the currency options</h3>
	
    Currency1<br>
    <input type='text' id='Currency1' required="required">

    <br><br>
	
	Value:<br>
    <input type='text' id='Value' required="required">
	
	<br><br>

    Currency2<br>
    <input type='text' id='Currency2' required="required">

    <br><br>
	
	<button id="button" > Convert Currency </button> -->
	
	Convert from: 
	<select id="Currency1" autofocus>
	<option value="USD">USD</option>
	<option value="EUR">EUR</option>
	<option value="GBP">GBP</option>
	<option value="CAD">CAD</option>
	<option value="AUD">AUD</option>
	<option value="JPY">JPY</option>
	<option value="CHF">CHF</option>
	<option value="SEK">SEK</option>
	</select>
	<br><br>
	
	Currency Value:<br>
    <input type='text' id='Value' required="required">
	
	<br><br>
	Convert to:
	<select id="Currency2" autofocus>
	<option value="EUR">EUR</option>
	<option value="GBP">GBP</option>
	<option value="CAD">CAD</option>
	<option value="AUD">AUD</option>
	<option value="JPY">JPY</option>
	<option value="CHF">CHF</option>
	<option value="SEK">SEK</option>
	<option value="USD">USD</option>
	</select>
	<button id="button" > Calculate </button>
<!--</form> -->


